package com.example.lanchefacilapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import androidx.appcompat.app.AppCompatActivity;

public class PedidoActivity extends AppCompatActivity {

    String lancheEscolhido = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pedido);

        EditText etNome = findViewById(R.id.etNomeCliente);

        Button btnHamburguer = findViewById(R.id.btnHamburguer);
        Button btnSanduiche = findViewById(R.id.btnSanduiche);
        Button btnPizza = findViewById(R.id.btnPizza);
        Button btnConfirmar = findViewById(R.id.btnConfirmarPedido);

        View.OnClickListener lancheClick = v -> {
            lancheEscolhido = ((Button) v).getText().toString();
        };

        btnHamburguer.setOnClickListener(lancheClick);
        btnSanduiche.setOnClickListener(lancheClick);
        btnPizza.setOnClickListener(lancheClick);

        btnConfirmar.setOnClickListener(v -> {
            String nome = etNome.getText().toString();
            Intent intent = new Intent(PedidoActivity.this, ResumoActivity.class);
            intent.putExtra("nome", nome);
            intent.putExtra("lanche", lancheEscolhido);
            startActivity(intent);
        });
    }
}
