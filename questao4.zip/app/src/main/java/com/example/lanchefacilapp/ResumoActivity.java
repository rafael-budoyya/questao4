package com.example.lanchefacilapp;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class ResumoActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_resumo);

        TextView tvResumo = findViewById(R.id.tvResumoPedido);
        Button btnVoltar = findViewById(R.id.btnVoltarInicio);

        String nome = getIntent().getStringExtra("nome");
        String lanche = getIntent().getStringExtra("lanche");

        String resumo = "Cliente: " + nome + "\nLanche: " + lanche;
        tvResumo.setText(resumo);

        btnVoltar.setOnClickListener(v -> {
            Intent intent = new Intent(ResumoActivity.this, MainActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
            startActivity(intent);
        });
    }
}
